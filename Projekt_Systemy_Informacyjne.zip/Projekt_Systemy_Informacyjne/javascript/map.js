var map = L.map('map', {});

// PAINEIS
map.createPane('pane_0').style.zIndex = 499;
map.createPane('pane_1').style.zIndex = 498;
map.createPane('pane_2').style.zIndex = 497;

var baseMaps = {};
var overlayMaps = {};

// CAMADAS BASE
var googleStreet = L.tileLayer('http://{s}.google.com/vt/lyrs=m,h&x={x}&y={y}&z={z}',{
	maxZoom: 20,
	subdomains:['mt0','mt1','mt2','mt3'],
	attribution: '<a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2021 Google</a>'
});
baseMaps["Google Street"] = googleStreet;

var googleSatellite = L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{
	maxZoom: 20,
	subdomains:['mt0','mt1','mt2','mt3'],
	attribution: '<a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2021 Google</a>'
});
baseMaps['Google Satellite'] = googleSatellite;

var googleHybrid = L.tileLayer('http://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}',{
	maxZoom: 20,
	subdomains:['mt0','mt1','mt2','mt3'],
	attribution: '<a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2021 Google</a>'
});
googleHybrid.addTo(map);
baseMaps["Google Hybrid"] = googleHybrid;

// CAMADAS VETORIAIS
var _Droga = L.geoJSON(_Droga_data, {
			pane: 'pane_0',
			style: function (feature) {
				if ( feature.properties["KATZARZ"] == 'gminna') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(102, 38, 212, 1.00)'
					}
				} else if ( feature.properties["KATZARZ"] == 'inna') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(214, 126, 195, 1.00)'
					}
				} else if ( feature.properties["KATZARZ"] == 'krajowa') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 10.3,
						color: 'rgba(0, 0, 0, 1.00)'
					}
				} else if ( feature.properties["KATZARZ"] == 'powiatowa') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 5.300000000000001,
						color: 'rgba(0, 0, 0, 1.00)'
					}
				} else if ( feature.properties["KATZARZ"] == 'wojewodzka') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 3.3000000000000003,
						color: 'rgba(0, 0, 0, 1.00)'
					}
				} else if ( feature.properties["KATZARZ"] == 'zakladowa') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(136, 183, 232, 1.00)'
					}
				} 
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: Droga</h4><br/>'  +
							'<b>KATZARZ:</b>&ensp;' + feature.properties['KATZARZ'] + '<br/>' +
							'<b>X_KOD:</b>&ensp;' + feature.properties['X_KOD'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['Droga'] = _Droga;

var _Obiekty_Wodne = L.geoJSON(_Obiekty_Wodne_data, {
			pane: 'pane_1',
			style: function (feature) {
				if ( feature.properties["X_KOD"] == 'rzeka') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 3.3000000000000003,
						color: 'rgba(100, 152, 210, 1.00)'
					}
				} else if ( feature.properties["X_KOD"] == 'strumień, potok lub struga') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(166, 206, 227, 1.00)'
					}
				} 
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: Obiekty Wodne</h4><br/>'  +
							'<b>CIEK_NAZWA:</b>&ensp;' + feature.properties['CIEK_NAZWA'] + '<br/>' +
							'<b>RODZAJ:</b>&ensp;' + feature.properties['RODZAJ'] + '<br/>' +
							'<b>X_KOD:</b>&ensp;' + feature.properties['X_KOD'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['Obiekty_Wodne'] = _Obiekty_Wodne;

var _Powiat_O_awski = L.geoJSON(_Powiat_O_awski_data, {
			pane: 'pane_2',
			style: function (feature) {
				if ( feature.properties["X_KOD"] == 'część miasta') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(247, 247, 247, 1.00)',
						fillColor: 'rgba(82, 82, 82, 1.00)'
					}
				} else if ( feature.properties["X_KOD"] == 'miasto') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(82, 82, 82, 1.00)',
						fillColor: 'rgba(204, 204, 204, 1.00)'
					}
				} else if ( feature.properties["X_KOD"] == 'osada') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(56, 128, 54, 1.00)',
						fillColor: 'rgba(77, 175, 74, 1.00)'
					}
				} else if ( feature.properties["X_KOD"] == 'państwo') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(82, 82, 82, 1.00)',
						fillColor: 'rgba(247, 247, 247, 1.00)'
					}
				} else if ( feature.properties["X_KOD"] == 'przysiółek') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(0, 0, 0, 1.00)',
						fillColor: 'rgba(255, 255, 255, 1.00)'
					}
				} else if ( feature.properties["X_KOD"] == 'wieś') {
					return {
						opacity: 1.0,
						fillOpacity: 1.0,
						weight: 1.3,
						color: 'rgba(82, 82, 82, 1.00)',
						fillColor: 'rgba(204, 204, 204, 1.00)'
					}
				} 
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: Powiat_Oławski</h4><br/>'  +
							'<b>LMIESZKANC:</b>&ensp;' + feature.properties['LMIESZKANC'] + '<br/>' +
							'<b>NAZWA:</b>&ensp;' + feature.properties['NAZWA'] + '<br/>' +
							'<b>RODZAJ:</b>&ensp;' + feature.properties['RODZAJ'] + '<br/>' +
							'<b>X_KOD:</b>&ensp;' + feature.properties['X_KOD'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['Powiat_O_awski'] = _Powiat_O_awski;

//Função que dá zoom sobre a feição clicada
function clickedFeature(e) {
	var feature = e.target;
	if (feature.feature.geometry.type == 'Point' ) {
		map.setView(feature.getLatLng(), 16);
	} else {
		map.fitBounds(feature.getBounds());
	}
}

// LEGENDA
var legend = L.control({position: 'bottomright'});
legend.onAdd = function (map) {
	var div = L.DomUtil.create('div', 'info legend');
	div.innerHTML = '<dl>';
	div.innerHTML += 	'<dt class="_Droga_lgd">Droga</dt>';
	div.innerHTML += 		'<dd class="_Droga_lgd"><svg class="legendIcon"><line x1="0" y1="9" x2="18" y2="9" stroke="rgba(102, 38, 212, 1.00)" stroke-width="3"></svg>gminna</dd>';
	div.innerHTML += 		'<dd class="_Droga_lgd"><svg class="legendIcon"><line x1="0" y1="9" x2="18" y2="9" stroke="rgba(214, 126, 195, 1.00)" stroke-width="3"></svg>inna</dd>';
	div.innerHTML += 		'<dd class="_Droga_lgd"><svg class="legendIcon"><line x1="0" y1="9" x2="18" y2="9" stroke="rgba(0, 0, 0, 1.00)" stroke-width="3"></svg>krajowa</dd>';
	div.innerHTML += 		'<dd class="_Droga_lgd"><svg class="legendIcon"><line x1="0" y1="9" x2="18" y2="9" stroke="rgba(0, 0, 0, 1.00)" stroke-width="3"></svg>powiatowa</dd>';
	div.innerHTML += 		'<dd class="_Droga_lgd"><svg class="legendIcon"><line x1="0" y1="9" x2="18" y2="9" stroke="rgba(0, 0, 0, 1.00)" stroke-width="3"></svg>wojewodzka</dd>';
	div.innerHTML += 		'<dd class="_Droga_lgd"><svg class="legendIcon"><line x1="0" y1="9" x2="18" y2="9" stroke="rgba(136, 183, 232, 1.00)" stroke-width="3"></svg>zakladowa</dd>';
	div.innerHTML += 	'<dt class="_Obiekty_Wodne_lgd">Obiekty Wodne</dt>';
	div.innerHTML += 		'<dd class="_Obiekty_Wodne_lgd"><svg class="legendIcon"><line x1="0" y1="9" x2="18" y2="9" stroke="rgba(100, 152, 210, 1.00)" stroke-width="3"></svg>rzeka</dd>';
	div.innerHTML += 		'<dd class="_Obiekty_Wodne_lgd"><svg class="legendIcon"><line x1="0" y1="9" x2="18" y2="9" stroke="rgba(166, 206, 227, 1.00)" stroke-width="3"></svg>strumień, potok lub struga</dd>';
	div.innerHTML += 	'<dt class="_Powiat_O_awski_lgd">Powiat_Oławski</dt>';
	div.innerHTML += 		'<dd class="_Powiat_O_awski_lgd"><svg class="legendIcon"><rect width="18" height="18" stroke="rgba(247, 247, 247, 1.00)" stroke-width="3" fill="rgba(82, 82, 82, 1.00)"></svg>część miasta</dd>';
	div.innerHTML += 		'<dd class="_Powiat_O_awski_lgd"><svg class="legendIcon"><rect width="18" height="18" stroke="rgba(82, 82, 82, 1.00)" stroke-width="3" fill="rgba(204, 204, 204, 1.00)"></svg>miasto</dd>';
	div.innerHTML += 		'<dd class="_Powiat_O_awski_lgd"><svg class="legendIcon"><rect width="18" height="18" stroke="rgba(56, 128, 54, 1.00)" stroke-width="3" fill="rgba(77, 175, 74, 1.00)"></svg>osada</dd>';
	div.innerHTML += 		'<dd class="_Powiat_O_awski_lgd"><svg class="legendIcon"><rect width="18" height="18" stroke="rgba(82, 82, 82, 1.00)" stroke-width="3" fill="rgba(247, 247, 247, 1.00)"></svg>państwo</dd>';
	div.innerHTML += 		'<dd class="_Powiat_O_awski_lgd"><svg class="legendIcon"><rect width="18" height="18" stroke="rgba(0, 0, 0, 1.00)" stroke-width="3" fill="rgba(255, 255, 255, 1.00)"></svg>przysiółek</dd>';
	div.innerHTML += 		'<dd class="_Powiat_O_awski_lgd"><svg class="legendIcon"><rect width="18" height="18" stroke="rgba(82, 82, 82, 1.00)" stroke-width="3" fill="rgba(204, 204, 204, 1.00)"></svg>wieś</dd>';
	div.innerHTML += '</dl>';
	return div
}
legend.addTo(map);

//ESCALA
L.control.scale({
	maxWidth: 250,
	imperial: false
}).addTo(map);

// CONTROLE DE CAMADAS
L.control.layers(baseMaps, overlayMaps, {
	position: 'topright',
	collapsed: false,
	sortLayers: true
}).addTo(map);

function layerON (event){
	var className = event.name + '_lgd';
	var legendItems = document.getElementsByClassName(className);
	for (var i = 0; i < legendItems.length; i++) {
		legendItems[i].style.display = 'block';
	}
}

function layerOFF (event){
	var className = event.name + '_lgd';
	var legendItems = document.getElementsByClassName(className);
	for (var i = 0; i < legendItems.length; i++) {
		legendItems[i].style.display = 'none';
	}
}

map.on('overlayadd', layerON);
map.on('overlayremove', layerOFF);

// CALCULA A AREA QUE COBRE TODAS AS CAMADAS
var bounds = {xmin: 180, ymin: 90, xmax: -180, ymax: -90};
for (var layer in overlayMaps) {
	var layerBounds = overlayMaps[layer].getBounds();
	if (bounds.xmin > layerBounds.getSouthWest().lng) {bounds.xmin = layerBounds.getSouthWest().lng};
	if (bounds.ymin > layerBounds.getSouthWest().lat) {bounds.ymin = layerBounds.getSouthWest().lat};
	if (bounds.xmax < layerBounds.getNorthEast().lng) {bounds.xmax = layerBounds.getNorthEast().lng};
	if (bounds.ymax < layerBounds.getNorthEast().lat) {bounds.ymax = layerBounds.getNorthEast().lat};
}
map.fitBounds([
	[bounds.ymin, bounds.xmin],
	[bounds.ymax, bounds.xmax]
]);
